<link rel="stylesheet" href="/css/styles/home.css">

<section id="home">
    <span class="background"></span>
    <div id="main">
        <div class="container">
            <div class="main-cont">
                <div class="main-name">
                    <h3>Транспортно-экспедиционная компания</h3>
                    <h1>Тысячи километров успеха и гаранта - С удовольствием для Вас</h1>

                    <button>Расчитать стоимость</button>

                </div>

            </div>
        </div>
    </div>
</section>
<script src="/js/resize.js"></script>

<script type="text/javascript">
    window.onload = function () {
        document.body.className += ' loaded'
    };
</script>