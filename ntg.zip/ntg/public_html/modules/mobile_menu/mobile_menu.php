<link href="/modules/mobile_menu/mobile_menu.css" rel="stylesheet">
<script src="/modules/mobile_menu/mobile_menu.js"></script>
<noscript>
	<link href="/modules/mobile_menu/no_js.css" rel="stylesheet">
</noscript>