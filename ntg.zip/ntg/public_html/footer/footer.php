<link rel="stylesheet" href="/css/styles/footer.css">

<footer>
    <div class="footer-fon"></div>
    <div class="container">
        <div class="card">
            <div class="row">
                <div class="col-12 col-md-4">
                    <ul>
                        <li class="name">
                            <h2>Контакты</h2>
                        </li>
                        <li>
                            <i class="icon ion-md-call fa-lg"></i>
                            +7 (707) 000 0000
                        </li>
                        <li>
                            <i class="icon ion-md-call fa-lg"></i>
                            +7 (707) 000 0000
                        </li>
                        <li>
                            <i class="icon ion-md-mail fa-lg"></i>
                            north-trans-group@gamil.com
                        </li>
                        <li>
                            <i class="icon ion-md-map fa-lg"></i>
                            ул.Бейбетшылык 18 / кб.220
                        </li>
                    </ul>
                </div>
                <div class="col-12 col-md-4">
                    <ul>
                        <li class="name">
                            <h2>Полезная инофрмация</h2>
                        </li>
                        <li>
                            <a href="#">
                                Lorem ipsum dolor
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Lorem ipsum dolor
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Lorem ipsum dolor
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Lorem ipsum dolor
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Lorem ipsum dolor
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-12 col-md-4">
                    <ul>
                        <li class="name">
                            <h2>Документы</h2>
                        </li>
                        <li>
                            <a href="/file/doc.txt" download>
                                <i class="icon ion-md-document fa-lg"></i>
                                Lorem ipsum dolor
                            </a>
                        </li>
                        <li>
                            <a href="/file/doc.txt" download>
                                <i class="icon ion-md-document fa-lg"></i>
                                Lorem ipsum dolor
                            </a>
                        </li>
                        <li>
                            <a href="/file/doc.txt" download>
                                <i class="icon ion-md-document fa-lg"></i>
                                Lorem ipsum dolor
                            </a>
                        </li>
                        <li>
                            <a href="/file/doc.txt" download>
                                <i class="icon ion-md-document fa-lg"></i>
                                Lorem ipsum dolor
                            </a>
                        </li>
                        <li>
                            <a href="/file/doc.txt" download>
                                <i class="icon ion-md-document fa-lg"></i>
                                Lorem ipsum dolor
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>