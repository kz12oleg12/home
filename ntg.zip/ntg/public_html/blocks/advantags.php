<link rel="stylesheet" href="/css/styles/adnantags.css">

<section id="advantags">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md br-r">
                <div class="name">
                    <h1>Почему мы</h1>
                </div>
            </div>
            <div class="col br-r">
                <h2>
                    <span>1200</span> заказов</h2>
            </div>
            <div class="col br-r">
                <h2>
                    <span>100%</span> гарантия</h2>
            </div>
            <div class="col">
                <h2>
                    <span>20</span> лет опыта</h2>
            </div>
        </div>
    </div>
</section>