<link rel="stylesheet" href="/css/styles/about.css">

<section id="about">
    <div class="container">
        <div class="row">
            <div class="col-4 d-none d-md-block">
                <div class="ab-img">
                    <img src="/img/logoAb.png" alt="">
                </div>
            </div>
            <div class="col">
                <div class="ab">
                    <div class="name">
                        <h3>О компании</h3>
                        <h2>North trans group</h2>
                        <div class="ab-line"></div>
                    </div>
                    <div class="content">
                        <p>
                            Мы акцентируем внимание на решении проблем и поставленных задач наших клиентов по доставке товара из любой точки мира сохранности
                            и в срок, что бы наш клиент понимал, что его товар в надежных руках.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>