<style>
</style>

<nav>
    <div class="container">
        <div class="navbar">
            <ul class="navbar-list">
                <a href="#bl_1" class="d-none d-lg-block">
                    <li class="nav-btn next-sl">
                        <i class="icon ion-md-arrow-down"></i>
                    </li>
                </a>
                <li class="nv-cl d-lg-none">
                    <div class="nav-close">
                        <i class="icon ion-ios-close fa-2x d-lg-none"></i>
                        Menu
                    </div>
                </li>
                <li>
                    <a href="#bl_2">
                        <i class="icon ion-ios-remove fa-lg d-lg-none"></i>
                        Vip Чартер</a>
                </li>
                <li>
                    <a href="#bl_3">
                        <i class="icon ion-ios-remove fa-lg d-lg-none"></i>
                        Групповой Чартер</a>
                </li>
                <li>
                    <a href="#bl_4">
                        <i class="icon ion-ios-remove fa-lg d-lg-none"></i>
                        Медицинский Чартер</a>
                </li>
                <li>
                    <a href="#bl_5">
                        <i class="icon ion-ios-remove fa-lg d-lg-none"></i>
                        Парк самлетов</a>
                </li>
                <li>
                    <a href="#bl_6">
                        <i class="icon ion-ios-remove fa-lg d-lg-none"></i>
                        Парк вертолетов</a>
                </li>
                <li>
                    <a href="#bl_7">
                        <i class="icon ion-ios-remove fa-lg d-lg-none"></i>
                        Менеджмент ВС</a>
                </li>
                <li>
                    <a href="#bl_8">
                        <i class="icon ion-ios-remove fa-lg d-lg-none"></i>
                        Комплексные решения</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div id="pause" class="jolk"></div>

