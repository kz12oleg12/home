<link rel="stylesheet" href="/css/bl/bl_4.css">

<section id="bl_4" class="bl">
    <!-- <div class="name">
        <h2> Самые популярныенаправления </h2>
    </div> -->
    <img class="gerl" src="/img/anim-el/gerl2.png" alt="">
    <div class="container">
        <div class="row no-gutters justify-content-end">
            <div class="col-12 col-lg-8">
                <div class="name">
                    <h2> Самые популярные направления 
                        <i class="icon ion-ios-remove fa-lg"></i>
                    </h2>
                </div>
            </div>
            <div class="col-12 col-lg-7">
                <div class="part">
                    <div class="row no-gutters justify-content-center">

                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="napr-it">
                                <a href="#"></a>
                                <h2>Санкт Петербург - Ницца</h2>
                                <h3>Цена аренды частного самолета от </h3>
                                <h3>31 000 €</h3>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>