<link rel="stylesheet" href="/css/bl/bl_7.css">
<section id="bl_7" class="bl">
    <img class="gerl" src="/img/anim-el/gerl3.png" alt="">
    <div class="container">
        <div class="row no-gutters justify-content-end">

            <div class="col-12 col-lg-8">
                <div class="row">
                    <div class="col-12 col-lg">
                        <div class="name">
                            <h2>Как с нами связаться
                                <i class="icon ion-ios-remove fa-lg"></i>
                            </h2>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="cont">
                            <div class="row">
                                <div class="col-12">

                                    <h2>Астана:</h2>

                                </div>
                                <div class="col-12 col-lg-6">

                                    <p>121357, Россия, Москва, ул.Верейская д.17, Бизнес-центр "Верейская Плаза-2", офис 411</p>
                                    <h3>Вермя работы офиса:</h3>
                                    <p>Пн-Пт с 10-00 до 19-00</p>

                                </div>
                                <div class="col-12 col-lg-6">
                                    <h3>Телефон: +7 (495) 755-77-55</h3>
                                    <h3>Факс: +7 (495) 755-99-75</h3>
                                    <h3>E-mail: info@yourcharter.ru</h3>
                                </div>
                                <div class="col-12">
                                    <form action="">
                                        <div class="row ">
                                            <div class="col-12 col-md-6">
                                                <div class="row">
                                                    <div class="col-12 ">
                                                        <div class="inp">
                                                            <div class="inp-icon">
                                                                <!-- <i class="icon ion-md-person fa-lg"></i> -->
                                                                <i class="pe-7s-user fa-lg"></i>
                                                            </div>
                                                            <input type="text" placeholder="Ваше имя">
                                                        </div>
                                                    </div>
                                                    <div class="col-12 ">
                                                        <div class="inp">
                                                            <div class="inp-icon">
                                                                <!-- <i class="icon ion-md-call fa-lg"></i> -->
                                                                <i class="pe-7s-call fa-lg"></i>
                                                            </div>
                                                            <input type="text" placeholder="Телефон">
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                            <div class="col-12 col-md-6">
                                                <textarea name="" id="" cols="30" rows="" placeholder="Cообщение:"></textarea>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="inp">
                                                    <input type="button" value="ОТПРАВИТЬ">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>