<link rel="stylesheet" href="/css/bl/bl_5.css">

<section id="bl_5" class="bl">
    <img class="gerl" src="/img/anim-el/gerl.png" alt="">
    <div class="bl-5-cont">
        <div class="container">
            <div class="row no-gutters justify-content-end">
                <div class="col-12 col-lg-8">
                    <div class="name">
                        <h2>Наши партнеры
                            <i class="icon ion-ios-remove fa-lg"></i>
                        </h2>
                    </div>
                </div>
                <div class="col-12 col-lg-7">
                    <div class="part">
                        <div class="row">
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                            <div class=" col-6 col-md-4">
                                <div class="pr-it">
                                    <img src="/img/part/2.png" alt="" width="100%">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>