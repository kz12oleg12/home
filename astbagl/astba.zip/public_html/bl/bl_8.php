<link rel="stylesheet" href="/css/bl/bl_8.css">

<section id="bl_8" class="bl">
    <div class="cont">
        <div class="footer-up ">
            <div class="container ">
                <div class="row justify-content-center ">
                    <div class="col-6 col-md-3  ">
                        <ul>
                            <li class="lk ">
                                <i class="icon ion-md-remove fa-lg "></i>
                            </li>
                            <li>
                                <a href="# ">
                                    Афиаброкер
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    VIP-чартер
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    VIP-авиация
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Частные перелеты
                                </a>
                            </li> 
                        </ul> 
                    </div>
                    <div class="col-6 col-md-3  ">
                        <ul>
                            <li class="lk ">
                                <i class="icon ion-md-remove fa-lg "></i>
                            </li>
                            <li>
                                <a href="# ">
                                    Калькулятор
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Санитарная авиация
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Аренда бизнес самолета
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Аэротакси
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-6 col-md-3  ">
                        <ul>
                            <li class="lk ">
                                <i class="icon ion-md-remove fa-lg "></i>
                            </li>
                            <li>
                                <a href="# ">
                                    VIP-авиаперевозки
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Срочный чартер
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Бизнес верталеты
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Бизнес самолеты
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-6 col-md-3  ">
                        <ul>
                            <li class="lk ">
                                <i class="icon ion-md-remove fa-lg "></i>
                            </li>
                            <li>
                                <a href="# ">
                                    Аренда верталета
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Заказать самолет
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Аренда самолета
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Частная авиация
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-dw ">
            <div class="container ">
                <div class="row justify-content-center ">
                    <div class="col-12 col-md-4 d-none d-lg-block">
                        <div class="dw-it ">
                            <div class="dw-line "></div>
                            <ul>
                            <li class="nt ">
                                <h2>Контакты</h2>
                            </li>
                            <li>

                                    121357,Россия, Московская область,Москва,ул.Верейская д.17,

                            </li>
                            <li>

                                    Бизнес-центр "Верейская Плаза-2 "бофис 441

                            </li>
                            <li>

                                    Время работы офиса:
                                    Пн-Пт с 10-00 до 19-00

                            </li>
                            <li>
                                    Телефон:+7 (495) 153-53-38
                                   </li> 
                                   <li>Факс:+7 (495) 153-53-38
                                    </li>
                                    <li>E-mail: info@yourcharter.ru

                            </li>
                        </ul>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4 ">
                        <div class="dw-it ">
                            <div class="dw-line "></div>
                        <ul>
                            
                                <li class="nt ">
                                        <h2>Информация для клиента</h2>
                                    </li>
                            <li>
                                <a href="# ">
                                    VIP-самолеты
                                    </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Деловая авиация
                                    </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Частные верталеты
                                    </a>
                            </li>
                            <li>
                                <a href="# ">
                                    Фрахт самолета
                                    </a>
                            </li>
                            <li>
                                <a href="# ">
                                Самолеты в чартер
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                Заказать VIP-фвиарейс
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                Бизнес джет
                                </a>
                            </li>
                            <li>
                                <a href="# ">
                                Аренда самолета с экипажем
                            </li>
                        </ul>
                    </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4 ">
                        <div class="dw-it ">
                            <div class="dw-line "></div>
                            <ul>
                                    <li class="nt ">
                                            <h2>Дополнительно</h2>
                                        </li>
                            <li>
                                <a href="# ">
                                
                                    Аренда частного самолета
                                
                            </li>
                            <li>
                                <a href="# ">
                                
                                    Медицинское споровождение
                                
                            </li>
                            <li>
                                <a href="# ">
                                
                                    Бизнес чартер
                                
                            </li>
                            <li>
                                <a href="# ">
                                
                                    Аренда частного самолета
                                
                            </li>
                            <li>
                                <a href="# ">
                                Аренда верталета
                            </li>
                            <li>
                                <a href="# ">
                                    Аренда верталета с пилотом
                            </li>
                            <li>
                                <a href="# ">
                                Авиатакси
                            </li>
                            <li>
                                <a href="# ">
                                Заказ верталета
                            </li>
                            
                        </ul>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-soc">
            <ul>
                <li>
                    <a href="#">
                        Whatsapp
                    </a>
                </li>
                <li class="qr"></li>
                <li>
                    <a href="#">
                        Telegram
                    </a>
                </li>
                <li class="qr"></li>
                <li>
                    <a href="#">
                        Viber
                    </a>
                </li>
            </ul>
        </div>
    </div>
    
</section>