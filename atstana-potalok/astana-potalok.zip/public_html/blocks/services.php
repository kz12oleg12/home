<link rel="stylesheet" href="/css/styles/services.css">

<section id="services">
    <div class="container">
        <div class="row">
            <!-- ITEM_1 -->
            <div class="col-12 col-md-6 col-lg-12">
                <div class="item">
                    <div class="row no-gutters">
                        <div class="col-12  col-lg-4">
                            <img src="/img/sr/1.jpg" alt="">
                        </div>
                        <div class="col">
                            <div class="content">
                                <div class="name al-r">
                                    <h2>Глянцевые</h2>
                                </div>
                                <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является
                                    стандартной "рыбой" для текстов на латинице с начала XVI века. Lorem Ipsum - это текст-"рыба",
                                    часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для
                                    текстов на латинице с начала XVI века.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ITEM_2 -->
            <div class="col-12 col-md-6 col-lg-12">
                <div class="item">
                    <div class="row no-gutters">
                        <div class="col-12  col-lg-4">
                            <img src="/img/sr/2.jpg" alt="">
                        </div>
                        <div class="col order-lg-first">
                            <div class="content">
                                <div class="name al-l">
                                    <h2>Матовые</h2>
                                </div>
                                <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является
                                    стандартной "рыбой" для текстов на латинице с начала XVI века. Lorem Ipsum - это текст-"рыба",
                                    часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для
                                    текстов на латинице с начала XVI века.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ITEM_3 -->
            <div class="col-12 col-md-6 col-lg-12">
                <div class="item">
                    <div class="row no-gutters">
                        <div class="col-12  col-lg-4">
                            <img src="/img/sr/3.jpg" alt="">
                        </div>
                        <div class="col">
                            <div class="content">
                                <div class="name al-r">
                                    <h2>Cатиновые</h2>
                                </div>
                                <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является
                                    стандартной "рыбой" для текстов на латинице с начала XVI века. Lorem Ipsum - это текст-"рыба",
                                    часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для
                                    текстов на латинице с начала XVI века.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ITEM_4 -->
            <div class="col-12 col-md-6 col-lg-12">
                <div class="item">
                    <div class="row no-gutters">
                        <div class="col-12  col-lg-4">
                            <img src="/img/sr/4.jpg" alt="">
                        </div>
                        <div class="col order-lg-first">
                            <div class="content">
                                <div class="name al-l">
                                    <h2>С фотопечатью</h2>
                                </div>
                                <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является
                                    стандартной "рыбой" для текстов на латинице с начала XVI века. Lorem Ipsum - это текст-"рыба",
                                    часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для
                                    текстов на латинице с начала XVI века.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ITEM_5 -->
            <div class="col-12 col-md-6 col-lg-12">
                <div class="item">
                    <div class="row no-gutters">
                        <div class="col-12  col-lg-4">
                            <img src="/img/sr/5.jpg" alt="">
                        </div>
                        <div class="col">
                            <div class="content">
                                <div class="name al-r">
                                    <h2>Многоуровневые</h2>
                                </div>
                                <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является
                                    стандартной "рыбой" для текстов на латинице с начала XVI века. Lorem Ipsum - это текст-"рыба",
                                    часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для
                                    текстов на латинице с начала XVI века.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ITEM_6 -->
            <div class="col-12 col-md-6 col-lg-12">
                <div class="item">
                    <div class="row no-gutters">
                        <div class="col-12  col-lg-4">
                            <img src="/img/sr/6.jpg" alt="">
                        </div>
                        <div class="col order-lg-first">
                            <div class="content">
                                <div class="name al-l">
                                    <h2>Звезное небо</h2>
                                </div>
                                <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является
                                    стандартной "рыбой" для текстов на латинице с начала XVI века. Lorem Ipsum - это текст-"рыба",
                                    часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для
                                    текстов на латинице с начала XVI века.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ITEM_7 -->
            <div class="col-12 col-md-6 col-lg-12">
                <div class="item">
                    <div class="row no-gutters">
                        <div class="col-12  col-lg-4">
                            <img src="/img/sr/7.jpg" alt="">
                        </div>
                        <div class="col">
                            <div class="content">
                                <div class="name al-r">
                                    <h2>С подсветкой</h2>
                                </div>
                                <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является
                                    стандартной "рыбой" для текстов на латинице с начала XVI века. Lorem Ipsum - это текст-"рыба",
                                    часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для
                                    текстов на латинице с начала XVI века.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ITEM_8 -->
            <div class="col-12 col-md-6 col-lg-12">
                <div class="item">
                    <div class="row no-gutters">
                        <div class="col-12  col-lg-4">
                            <img src="/img/sr/8.jpg" alt="">
                        </div>
                        <div class="col order-lg-first">
                            <div class="content">
                                <div class="name al-l">
                                    <h2>Эксклюзивные</h2>
                                </div>
                                <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является
                                    стандартной "рыбой" для текстов на латинице с начала XVI века. Lorem Ipsum - это текст-"рыба",
                                    часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для
                                    текстов на латинице с начала XVI века.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>