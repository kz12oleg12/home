<link rel="stylesheet" href="/css/styles/advantags.css">

<section id="advantags">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg">
                <div class="item">
                    <div class="name">
                        <h2>Почему мы</h2>
                    </div>
                </div>
            </div>

            <div class="col-auto d-none d-lg-block">
                <div class="item">
                    <div class="lin"></div>
                </div>
            </div>

            <div class="col-12  col-md col-lg">
                <div class="item">
                    <div class="name">
                        <h2>7</h2>
                    </div>
                    <h3>лет опыта</h3>
                </div>
            </div>

            <div class="col-auto d-none d-md-block d-lg-block">
                <div class="item">
                    <div class="lin"></div>
                </div>
            </div>

            <div class="col-12  col-md col-lg">
                <div class="item">
                    <i class="icon ion-md-apps fa-lg"></i>
                    <h3>Большой выбор</h3>
                </div>
            </div>

            <div class="col-auto d-none d-md-block d-lg-block">
                <div class="item">
                    <div class="lin"></div>
                </div>
            </div>

            <div class="col-12  col-md col-lg">
                <div class="item">
                    <i class="icon ion-md-settings fa-lg"></i>
                    <h3>установка за <span>1</span> день</h3>
                </div>
            </div>
        </div>
    </div>
</section>