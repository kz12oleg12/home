<link rel="stylesheet" href="/css/styles/about.css">

<section id="about">
    <div class="container">
        <div class="name">
            <h2>
                Astana Potalok
            </h2>
        </div>
        <div class="content">
            <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой"
                для текстов на латинице с начала XVI века.</p>
        </div>
    </div>
</section>