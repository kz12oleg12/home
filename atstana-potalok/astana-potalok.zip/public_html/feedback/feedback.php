<link rel="stylesheet" href="/css/styles/feedback.css">

<section id="feedback" class="bg bgdark">
    <div class="container">
            <div class="row">
                <div class="col-12 col-lg-4 order-12 order-lg-1" >
                    <form action="">
                        <input type="text" placeholder="Ваше имя">
                        <input type="text" placeholder="Телефон">
                        <input type="button" value="ОТПРАВИТЬ">
                    </form>
                </div>
                <div class="col order-1 order-lg-12">
                    <div class="name">
                        <h3 class="pd">Не откладывай</h3>
                        <h2 class="pd">Отправть заявку прямо сейчас</h2>
                    </div>
                </div>
            </div>
        </div>
</section>