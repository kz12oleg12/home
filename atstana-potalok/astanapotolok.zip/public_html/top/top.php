<link rel="stylesheet" href="/css/styles/header.css">
<header>

    <div class="container top">
        <div class="row">
            <div class="col-auto align-content-center fl">
                <div class="item align-content-center">
                    <div class="brand">
                        <h1>Astana-potolok</h1>
                    </div>
                </div>
            </div>
            <div class="col-auto align-content-center fl ml-auto ">
                <div class="item align-content-center">
                    <nav>
                        <ul class="nav-list">
                            <li class="item-close d-lg-none">
                                <button class="nav-btn-close">
                                    <i class="icon ion-md-close"></i>
                                </button>
                            </li>
                            <li class="item">
                                <a href="#">
                                    Главная
                                </a>
                            </li>
                            <li class="item">
                                <a href="#">
                                    О нас
                                </a>
                            </li>
                            <li class="item">
                                <a href="#">
                                    Услуги
                                </a>
                            </li>
                            <li class="item end">
                                <a href="#">
                                    Контакты
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="col-auto align-content-center fl ml-auto d-lg-none">
                <button class="nav-btn">
                    <i class="fa fa-bars fa-lg"></i>
                </button>
            </div>
        </div>
    </div>
    <div class="jolk"></div>
</header>


