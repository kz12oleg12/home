<section id="advantages" class="bl" style="height: 300px; background: rgb(223, 223, 223)">
    <h2>Услуги</h2>
</section>