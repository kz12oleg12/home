<section id="advantages" class="bl" style="height: 100px; background: rgb(237, 237, 237)">
    <h2>Преимущества</h2>
</section>