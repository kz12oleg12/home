<link rel="stylesheet" href="/css/styles/home.css">

<section id="home" class="bg bgdark">
    <span class="background"></span>
    <div id="main">
        <div class="container">
            <div class="main-cont">
                <div class="main-name">
                    <h2>Сделай свой дом лучше</h2>
                    <!-- <h3 class="s1">Натяжные потолки в Астане</h3>
                    <h3 class="s2">Натяжные потолки в Астане</h3>
                    <h3 class="s3">Натяжные потолки в Астане</h3>
                    <h3 class="s4">Натяжные потолки в Астане</h3> -->
                    <h3 class="s5">Натяжные потолки в Астане</h3>
                </div>

            </div>
        </div>
    </div>
</section>
<script src="/js/resize.js"></script>

<script type="text/javascript">
    window.onload = function () {
        document.body.className += ' loaded'
    };
</script>