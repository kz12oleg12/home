<section id="advantages" class="bl" style="height: 200px; background: transparent url('/img/feedback.jpg')no-repeat center center; background-size: 100%;">
    <h2>Обратная связь</h2>
</section>