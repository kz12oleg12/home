<section id="advantages" class="bl" style="height: 150px; color: white; background: black">
    <h2>Подвал</h2>
</section>